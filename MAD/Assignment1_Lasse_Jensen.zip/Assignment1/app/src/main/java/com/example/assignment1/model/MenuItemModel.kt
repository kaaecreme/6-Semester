package com.example.assignment1.model

import androidx.compose.ui.graphics.vector.ImageVector

data class MenuItemModel(
    val title: String,
    val description: String,
    val imageVector: ImageVector,
    val action: () -> Unit
)