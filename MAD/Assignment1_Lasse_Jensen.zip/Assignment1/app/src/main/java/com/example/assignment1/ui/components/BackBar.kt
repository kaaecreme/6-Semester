package com.example.assignment1.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import com.example.assignment1.FootballActivity
import com.example.assignment1.FormulaActivity
import com.example.assignment1.MainActivity
import com.example.assignment1.SoccerActivity
import com.example.assignment1.backend.model.Sport
import com.example.assignment1.backend.model.Teams


@Composable
fun BackBar(title: String, team: Teams?, content: @Composable () -> Unit) {
    val context = LocalContext.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically // Align items vertically
    ) {
        IconButton(onClick = {
            if(team == null){
                val intent = Intent(context, MainActivity::class.java)
                context.startActivity(intent)
            }
            if (team != null) {
                if(team.sport == Sport.American_Football){
                    val intent = Intent(context, FootballActivity::class.java)
                    context.startActivity(intent)
                }
                else if(team.sport == Sport.Formula_1){
                    val intent = Intent(context, FormulaActivity::class.java)
                    context.startActivity(intent)
                }
                else if(team.sport == Sport.Soccer){
                    val intent = Intent(context, SoccerActivity::class.java)
                    context.startActivity(intent)
                }
            }
        }) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "BackButton",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        Text(
            style = MaterialTheme.typography.bodyLarge.copy(
                color = MaterialTheme.colorScheme.onSurface
            ),
            text = title
        )
    }
}
