package com.example.assignment1.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DrawerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.assignment1.model.MenuItemModel
import kotlinx.coroutines.launch

@Composable
fun Drawer(
    menuItemModels: List<MenuItemModel>,
    drawerState: DrawerState,
    content: @Composable () -> Unit
) {
    val scope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color.Gray,
                drawerContentColor = MaterialTheme.colorScheme.background
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    menuItemModels.map {
                        MenuItem(model = it.copy(action = {
                            scope.launch {
                                it.action()
                                drawerState.close()
                            }
                        }))
                    }
                }
            }
        }, modifier = Modifier,drawerState = drawerState, gesturesEnabled = true, content = content
    )
}