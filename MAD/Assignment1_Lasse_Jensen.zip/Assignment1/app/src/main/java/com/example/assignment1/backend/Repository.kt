package com.example.assignment1.backend

import android.util.Log
import com.example.assignment1.backend.model.TeamsOverview
import com.example.assignment1.backend.model.Sport
import com.example.assignment1.backend.model.Teams
import com.example.assignment1.R
import java.time.LocalDate

object Repository {
    private val Teams = listOf(
        Teams(
            "Green Bay Packers",
            Sport.American_Football,
            R.drawable.greenbaypackers,
            "Jordan Love",
            R.drawable.jordanlove
        ),
        Teams(
            "Kansas City Chiefs",
            Sport.American_Football,
            R.drawable.kansascitychiefs,
            "Patrick Mahomes",
            R.drawable.patrickmahomes
        ),
        Teams(
            "Ferrari",
            Sport.Formula_1,
            R.drawable.ferrari,
            "Charles Leclerc",
            R.drawable.charlesleclerc
        ),
        Teams(
            "Haas",
            Sport.Formula_1,
            R.drawable.haas,
            "Kevin Magnussen",
            R.drawable.kevinmagnussen
        ),
        Teams(
            "Liverpool",
            Sport.Soccer,
            R.drawable.liverpool,
            "Virgil Van Dijk",
            R.drawable.vandijk
        ),
        Teams(
            "AGF",
            Sport.Soccer,
            R.drawable.agf,
            "Mikael Anderson",
            R.drawable.anderson
        )

    )

    fun getAmericanFootballList(): List<TeamsOverview> {
        return Teams.filter { it.sport == Sport.American_Football }
            .map { TeamsOverview(it.name, it.imageId) }
    }

    fun getFormula1List(): List<TeamsOverview> {
        return Teams.filter { it.sport == Sport.Formula_1 }
            .map { TeamsOverview(it.name, it.imageId) }
    }

    fun getSoccerList(): List<TeamsOverview> {
        return Teams.filter { it.sport == Sport.Soccer }
            .map { TeamsOverview(it.name, it.imageId) }
    }

    fun getTeam(name: String?): Teams? {
        return Teams.find { it.name == name }
    }

    fun getPlayer(teamName: String): String? {
        val team = Teams.find { it.name == teamName }
        return team?.bestPlayer
    }
}