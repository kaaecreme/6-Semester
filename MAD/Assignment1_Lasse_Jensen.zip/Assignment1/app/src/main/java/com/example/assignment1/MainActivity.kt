package com.example.assignment1

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import com.example.assignment1.model.MenuItemModel
import com.example.assignment1.ui.components.Menu
import com.example.assignment1.ui.screens.Home
import com.example.assignment1.ui.theme.Assignment1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Assignment1Theme {
                val menuItemModels = listOf(
                    MenuItemModel(
                        "American Football",
                        "FOOTBALL",
                        ImageVector.vectorResource(id = R.drawable.ic_football_foreground)
                    ) {
                        val intent = Intent(this, FootballActivity::class.java)
                        startActivity(intent)
                    },
                    MenuItemModel(
                        "Formula 1",
                        "FORMULA1",
                        ImageVector.vectorResource(id = R.drawable.ic_formula_car_foreground)
                    ) {
                        val intent = Intent(this, FormulaActivity::class.java)
                        startActivity(intent)
                    },
                    MenuItemModel(
                        "Soccer",
                        "SOCCER",
                        ImageVector.vectorResource(id = R.drawable.ic_soccer_foreground)
                    ) {
                        val intent = Intent(this, SoccerActivity::class.java)
                        startActivity(intent)
                    },
                )
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column {
                        Menu(title = "SPORTS", menuItemModels) {
                            Home()
                        }
                    }
                }
            }
        }
    }
}


