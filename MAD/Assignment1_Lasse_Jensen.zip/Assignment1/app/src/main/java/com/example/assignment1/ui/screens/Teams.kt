package com.example.assignment1.ui.screens

import androidx.compose.runtime.Composable
import com.example.assignment1.backend.Repository
import com.example.assignment1.ui.components.sports.Teams

@Composable
fun TeamsScreen(teamName: String?) {
    val team = Repository.getTeam(teamName)
    if (team != null) {
        Teams(team)
    } else {
        Error("No Team Found")
    }
}