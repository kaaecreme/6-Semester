package com.example.assignment1.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.assignment1.model.MenuItemModel

@Composable
fun MenuItem(model: MenuItemModel) {
    NavigationDrawerItem(
        modifier = Modifier.fillMaxWidth(),
        label = { Text(model.title) },
        icon = {
            Icon(
                imageVector = model.imageVector,
                contentDescription = model.description,
                tint = Color.White
            )
        },
        selected = false,
        onClick = model.action
    )
}