package com.example.assignment1.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.assignment1.TeamActivity
import com.example.assignment1.backend.Repository
import com.example.assignment1.ui.components.sports.SoccerItem


@Composable
fun SoccerScreen() {
    val context = LocalContext.current
    Column() {
        Repository.getSoccerList()
            .map {
                SoccerItem(name = it.name, imageId = it.imageId) {
                    var intent =
                        Intent(context, TeamActivity::class.java)
                    intent.putExtra("name", it.name)
                    context.startActivity(intent)
                }
            }
    }
}