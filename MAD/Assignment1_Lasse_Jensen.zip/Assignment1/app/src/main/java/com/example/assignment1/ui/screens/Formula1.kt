package com.example.assignment1.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.assignment1.TeamActivity
import com.example.assignment1.backend.Repository
import com.example.assignment1.ui.components.sports.FormulaItem


@Composable
fun Formula1Screen() {
    val context = LocalContext.current
    Column() {
        Repository.getFormula1List()
            .map {
                FormulaItem(name = it.name, imageId = it.imageId) {
                    var intent =
                        Intent(context, TeamActivity::class.java)
                    intent.putExtra("name", it.name)
                    context.startActivity(intent)
                }
            }
    }
}