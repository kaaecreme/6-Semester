package com.example.assignment1.backend.model

enum class Sport{
    American_Football,
    Formula_1,
    Soccer
}

data class Teams(val name: String, val sport: Sport, val imageId:Int, val bestPlayer: String, val imageIdPlayer: Int)
data class TeamsOverview(val name: String, val imageId: Int)
