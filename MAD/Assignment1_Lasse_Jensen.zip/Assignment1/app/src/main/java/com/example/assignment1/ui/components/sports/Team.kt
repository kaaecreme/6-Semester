package com.example.assignment1.ui.components.sports

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignment1.backend.model.Teams
import com.example.assignment1.ui.components.BackBar

@Composable

fun Teams(teams: Teams) = if (teams == null) {
    Text("error")
} else {
    Column() {
        BackBar(title = "Go back", team = teams) {
        }
            Row(
                Modifier
                    .padding(all = 5.dp)
                    .background(Color.Gray)
                    ) {
                Text(
                    modifier = Modifier
                        .align(Alignment.CenterVertically)
                        .fillMaxWidth()
                        .padding(50.dp),
                    text = "The best player of "  + teams.name + " is:\n" + teams.bestPlayer,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = TextStyle(fontSize = 24.sp) // Adjust the value (24.sp) for desired size
                )
            }
        Image(
            painter = painterResource(id = teams.imageIdPlayer),
            contentDescription = "Team image",
            modifier = Modifier.fillMaxSize()
        )
    }
}




