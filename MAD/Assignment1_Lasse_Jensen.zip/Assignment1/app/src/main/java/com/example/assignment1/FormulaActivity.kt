package com.example.assignment1

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import com.example.assignment1.model.MenuItemModel
import com.example.assignment1.ui.components.Menu
import com.example.assignment1.ui.theme.Assignment1Theme
import com.example.assignment1.ui.screens.Formula1Screen
import com.example.assignment1.ui.components.BackBar


class FormulaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Assignment1Theme {
                val menuItemModels =
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column {
                        BackBar(title = "Formula 1", team = null) {
                        }
                        Formula1Screen()
                    }

                }
            }

        }
    }
}